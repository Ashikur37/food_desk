<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderDayPickup extends Model
{
    protected $guarded = [];
}
