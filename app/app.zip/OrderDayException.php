<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderDayException extends Model
{
    protected $guarded = [];
}
