{!!$setting->offline_message!!}
