<?php

return [
    'Create New Admin' => 'হ্যালো'
];
