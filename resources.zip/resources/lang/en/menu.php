<?php

return [
    'GroupName' => 'Group Name',
    'Manufacturer' => 'Manufacturer',
    'MedicineType' => 'Medicine Type',
    'UnitType' => 'Unit Type',
    'Shelf' => 'Shelf',
    'Medicine' => 'Medicine',
    'MedicineUnitType' => 'Medicine Unit Type',
    'Supplier' => 'Supplier',
    'SupplierOrder' => 'Supplier Order',
    'Customer' => 'Customer',
    'CustomerOrder' => 'Customer Order',
    'SupplierOrderReturn' => 'Supplier Order Return',
    'CustomerOrderReturn' => 'Customer Order Return',
    'Wastage' => 'Wastage',
    'ExpenseType' => 'Expense Type',
    'Expense' => 'Expense',
    'Staff' => 'Staff',
    'StaffDuty' => 'Staff Duty',
    'StaffPayment' => 'Staff Payment',
    'User' => 'User',
    'Note' => 'Note',

];
