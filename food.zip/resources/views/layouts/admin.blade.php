  @include('layouts.admin.header')

  <!-- Main Sidebar Container -->
  @include('layouts.admin.aside')
@yield('content') 
  <!-- Content Wrapper. Contains page content -->

  <!-- /.content-wrapper -->
  @include('layouts.admin.footer')