<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PickupTimeException extends Model
{
    protected $guarded = [];
}
