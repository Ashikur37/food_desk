<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Controllers\Controller;
use App\Setting;
use Illuminate\Http\Request;

class HomeController extends Controller
{

    public function index()
    {
        $categories = Category::all();
        return view('front.home', compact('categories'));
    }

    public function Home()
    {
        $setting = Setting::firstOrFail();
        if ($setting->offline == 1) {
            return view('front.offline');
        }
        $categories = Category::orderBy('name')->with('subCategories')->get();
        return view('front.home', compact('categories'));
    }
    public function filterCategory(Request $request)
    {
        $categories = Category::where($request->key, 'like', '%' . $request->val . '%')->get();
        return view('includes.categoryFilter', compact('categories'));
    }
}
