<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Alergant extends Model
{
    protected $guarded = [];
    
}
