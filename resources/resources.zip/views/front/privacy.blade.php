@extends('layouts.front') @section('content')

{!!$setting->privacy!!}

@endsection