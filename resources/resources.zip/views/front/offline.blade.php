@extends('layouts.front') @section('content')
{!!$setting->offline_message!!}
@endsection
