@extends('layouts.front') @section('content')

{!!$setting->terms!!}

@endsection