<?php

return [
    'welcome' => 'হ্যালো'
];
