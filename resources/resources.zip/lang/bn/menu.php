<?php

return [
    'GroupName' => 'গ্রুপ নাম',
    'Manufacturer' => 'প্রস্তুতকারক',
    'MedicineType' => 'ঔষধের ধরন',
    'UnitType' => 'মাপের ধরন',
    'Shelf' => 'তাক',
    'Medicine' => 'ঔষধ',
    'MedicineUnitType' => 'ঔষধের মাপের ধরন',
    'Supplier' => 'সাপ্লায়ার',
    'SupplierOrder' => 'Group Name',
    'Customer' => 'ক্রেতা',
    'CustomerOrder' => 'Group Name',
    'SupplierOrderReturn' => 'Group Name',
    'CustomerOrderReturn' => 'Group Name',
    'Wastage' => 'অপচয়',
    'ExpenseType' => 'খরচের ধরন',
    'Expense' => 'খরচ',
    'Staff' => 'কর্মচারী',
    'StaffDuty' => 'কর্মচারীর ডিউটি',
    'StaffPayment' => 'কর্মচারীর বেতন',
    'User' => 'ব্যবহারকারী',
    'Note' => 'নোট',
    'Purchase' => 'ক্রয়',
    'Sale' => 'বিক্রয়',

    

];
